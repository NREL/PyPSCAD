# Rick Wallace Kenyon
# March 18, 2020
# Grabs the output channels listed in channel_names, and contained within the namespaces
# Will omit 

import numpy as np
import math, re
import sys
sys.path.append(r'C:\Users\rkenyon\Desktop\Maui\PSCAD\Maui_32')
import Wallace_PSCAD_Python as WPP
from sys import argv

if len(argv) != 3:
    print('Insufficient arguements provided. %r given, need 3.' % len(argv))
    exit()

channel_file = argv[2] + '_Channel_Names.csv'
channel_names = WPP.OpenUnpack(channel_file,BusChannel=True,Skip=False)

start_time = 0.0
sel_interval = 0.001
if 'Vabc' in channel_file:
    sel_interval = 0.0001
if 'Iabc' in channel_file:
    sel_interval = 0.0001

#fortran_id = '.if15_x86'
fortran_id = '.gf42'

# Namespaces in the system. Must be listed here, or else ignored
namespace_file = 'Namespaces_39.txt'
Housing = []
names_file = open(namespace_file).readlines()
for line in names_file:
    namespace = line.strip('\n')
    Housing.append({'Namespace':namespace})

save_file = 'Data_' + argv[1] + '_' + argv[2] + '.csv'

def File_Names(namespaces):
    # Creates file names from namespace names
    files = []
    for namespace in namespaces:
        file_name = namespace['Namespace'] + fortran_id + '/' + namespace['Namespace']
        files.append(file_name)
    return files

def INFX_Files_Search(infx_files,channel_name):
    # Walks through all infx files to locate channel. If found, extract file number, and column number
    # If not found, prints name to terminal and returns empty dict
    found = 0
    for infx_file in infx_files:
        temp_file = open(infx_file + '.infx').readlines()
        for line in temp_file:
            if (':' + channel_name + '"') in line:
                temp_line = line.split(' ')
                index = temp_line[6].split('=')[1].strip('"')
                file_number = math.floor(int(index)/10) + 1
                file_column = 1 + ( int(index) % 10 )
                namespace = infx_file.split('/')[1]
                found = 1
                break
        else:
            continue
        break
    if found:
        return {'Channel': channel_name, 'Namespace': namespace, 'File Number': file_number, 'File Column': file_column}
    else: 
        print('Could not find channel with name: %s' % channel_name)
        return {}

def Grab_Data_Column(channel_info):
    # Opens file for channel based on channel_info dictionary with relevant fields. Extracts line and returns as a numpy column
    if channel_info['File Number'] < 10:
        file_number = '_0' + str(channel_info['File Number']) + '.out'
    else:
        file_number = '_' + str(channel_info['File Number']) + '.out'
    file_name = channel_info['Namespace'] + fortran_id + '/' + channel_info['Namespace'] + file_number
    temp_data = np.genfromtxt(file_name,skip_header=1)
    return temp_data[:,channel_info['File Column']]

def Desired_Data_Points(time_vector,start_time,sel_int):
    # Assumes time_vector is a numpy array. Generates list of elem indexes, starting at start time and grabbing for desired interval
    desired = []
    interval = time_vector[1] - time_vector[0]
    if time_vector[0] > start_time:
        start_time = time_vector[0]
    for j in range(0,time_vector.shape[0]):
        # print(time_vector[j])
        # print(abs(start_time - time_vector[j]))
        if abs(start_time - time_vector[j]) <= (1.1 * interval/2):
            desired.append(j)
            start_time += sel_int
    return desired
# Build namespace file directories
infx_file_names = File_Names(Housing)

# First channel info name is for a time column (this isn't adaptive)
Channel_Info = [{'Channel': 'Time', 'Namespace': 'Central_39', 'File Number': 1, 'File Column': 0}]

# Walk through all names in channel_names and location file and number. Skips channels not found by checking if dict is empty, prints name to terminal
for elem in channel_names:
    temp = INFX_Files_Search(infx_file_names,elem)
    if temp:
        Channel_Info.append(temp)

# Establish the numpy array, based on length from time column. First column becomes time
time = Grab_Data_Column(Channel_Info[0])
temp_data = np.empty([time.shape[0],len(Channel_Info)])
temp_data[:,0] = time[:]
save_header = 'Time'

# Walks through the located channels and adds data to array
for i in range(1,len(Channel_Info)):
    temp_data[:,i] = Grab_Data_Column(Channel_Info[i])
    save_header = save_header + ', ' + Channel_Info[i]['Channel']

# Configures list of element indices for chosen data points
desired_data_column = Desired_Data_Points(time,start_time,sel_interval)

# Broadcast temp data to the desired
desired_data = temp_data[desired_data_column,:]

# Saves file, with header based on extracted data
np.savetxt(save_file, desired_data, delimiter=",", header = save_header)